#include <cmath>
#include <cassert>
#include <iostream>

const double PI = -atan2(-1,0);

class Shape{
public:

  virtual double perimeter() const = 0;
};

class Circle : public Shape{
public :

  Circle(double radius = 0): m_radius(radius) {};

  double radius(){ return m_radius;}

  double perimeter() const{
    return 2*PI*m_radius;
  }

  
  private:
    double m_radius = 0;
};

class Square: public Shape{
public:

  Square(double sidelen = 0): m_sidelen(sidelen){}

  double sidelen(){ return m_sidelen; }
  
  double perimeter() const{
    return 4*m_sidelen;
  }

private:

  double m_sidelen = 0;
};


void print_shape(const Shape & shape){
  std::cout << shape.perimeter() << "\n";
}

template<typename T>
void print_shape2(const T & shape){
  std::cout << shape.perimeter() << "\n";
}

int main(int argc, char *argv[])
{
  Circle c1(2);

  assert(c1.radius() == 2);
  assert(c1.perimeter() == 4*PI);
  
  Square s1(2);

  assert(s1.sidelen() == 2);
  assert(s1.perimeter() == 8);

  print_shape(c1);
  print_shape(s1);

  print_shape2(c1);
  print_shape2(s1);
  
  std::cout << "Passed.\n";
  
  return 0;
}
