#include <iostream>

class BaseClass{
public:

  BaseClass(){
    std::cout << "BaseClass() called.\n";
  }

  ~BaseClass(){
    std::cout << "~BaseClass() called.\n";
  }
};

class DerivedClass: public BaseClass{
public:

  DerivedClass(){
    std::cout << "DerivedClass() called.\n";
  }

  ~DerivedClass(){
    std::cout << "~DerivedClass() called.\n";
  }
  
};
  
int main(int argc, char *argv[])
{
  
  BaseClass * base_pointer = new DerivedClass();

  // do stuff

  delete base_pointer;
  
  return 0;
}
