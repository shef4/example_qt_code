#ifndef SETTINGS_H
#define SETTINGS_H

struct Settings{
  double width;
  double height;
};


#endif
