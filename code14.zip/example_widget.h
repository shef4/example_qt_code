#ifndef EXAMPLE_WIDGET_H
#define EXAMPLE_WIDGET_H

#include <QWidget>

class ExampleWidget: public QWidget{
Q_OBJECT

public:

  ExampleWidget(QWidget * parent = nullptr);

  
};

#endif
