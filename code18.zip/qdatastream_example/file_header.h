
#ifndef _FILE_HEADER_H_
#define _FILE_HEADER_H_

// you can make this up, but note there are registered/standard magic
// numbers to avoid, e.g. png format is the sequence 89 50 4e 47
quint32 MAGIC = 85634534;
qint32 VERSION = 1;


#endif // _FILE_HEADER_H_
